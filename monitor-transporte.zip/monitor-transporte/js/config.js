/**
 * config.js
 * ---------------------------------------------------------------
 * Configuración central de la aplicación. Es el ÚNICO archivo que
 * debería tocarse para cambiar fuentes de datos, proxy o refresco.
 *
 * El modo inicial se puede forzar por URL:
 *   index.html?modo=mock   → datos simulados (por defecto)
 *   index.html?modo=real   → feeds GTFS-RT configurados abajo
 */

export const CONFIG = {
  /** Modo por defecto si la URL no indica ?modo= */
  modoPorDefecto: 'mock',

  /** Segundos entre actualizaciones del mapa */
  intervaloRefrescoSeg: 10,

  /** Tiempo máximo de espera de cada petición HTTP (ms) */
  timeoutPeticionMs: 15000,

  /** Ruta al archivo de estilos (colores y umbrales de retraso) */
  rutaEstilos: 'data/estilo_mapa.json',

  /** Vista inicial del mapa: centro de la Península */
  mapa: {
    centro: [40.2, -3.7],
    zoom: 6,
    zoomMin: 5,
    zoomMax: 18,
    // Teselas estándar de OpenStreetMap: sin clave, válidas para uso ligero
    // (política: https://operations.osmfoundation.org/policies/tiles/).
    // Si el tráfico crece, cambia a un proveedor con clave (MapTiler, Stadia…).
    teselas: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
    subdominios: '',
    atribucion: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
  },

  /**
   * Proxy CORS. Si un feed no envía la cabecera Access-Control-Allow-Origin,
   * el navegador bloqueará la petición. En ese caso se antepone esta URL.
   * Formato esperado: el proxy recibe la URL destino codificada en ?url=
   * (compatible con el Worker incluido en /proxy/cloudflare-worker.js).
   * Déjalo en '' para no usar proxy.
   */
  proxyCors: '',

  /** Color para vehículos sin dato de retraso (no viene en estilo_mapa.json) */
  colorSinDatos: '#94a3b8',

  /** Configuración del modo de datos simulados */
  mock: {
    ruta: 'data/mock_gtfs_rt.json',
    /**
     * OJO: el estándar GTFS-RT define position.speed en m/s, pero el mock
     * trae km/h (280.5 en un AVE serían ~1.010 km/h si fueran m/s).
     */
    unidadVelocidad: 'km/h',
    /** Mueve los trenes en cada refresco según rumbo y velocidad */
    animar: true,
    /** Añade trenes ficticios para ver los cuatro estados en el mapa */
    generarSinteticos: true,
    /** Varía ligeramente el retraso entre refrescos */
    variarRetrasos: true,
  },

  /**
   * Feeds reales. Cada fuente puede tener posiciones de vehículos y,
   * opcionalmente, actualizaciones de viaje (de donde sale el retraso).
   * formato: 'json' | 'protobuf' | 'auto' (decide por Content-Type)
   * usarProxy: true si el servidor no permite CORS.
   *
   * Feeds de Renfe comprobados el 01/11/2026: responden en JSON (claves
   * camelCase) pero SIN cabecera CORS, así que desde GitHub Pages
   * necesitan proxy. No traen rumbo ni velocidad: los marcadores se
   * pintan como punto en vez de flecha.
   */
  fuentesReales: [
    {
      id: 'renfe-cercanias',
      nombre: 'Renfe Cercanías',
      activa: true,
      posiciones: 'https://gtfsrt.renfe.com/vehicle_positions.json',
      actualizacionesViaje: 'https://gtfsrt.renfe.com/trip_updates.json',
      formato: 'auto',
      unidadVelocidad: 'm/s',
      usarProxy: true,
    },
    {
      id: 'renfe-ld',
      nombre: 'Renfe AV / LD / MD',
      activa: true,
      posiciones: 'https://gtfsrt.renfe.com/vehicle_positions_LD.json',
      actualizacionesViaje: 'https://gtfsrt.renfe.com/trip_updates_LD.json',
      formato: 'auto',
      unidadVelocidad: 'm/s',
      usarProxy: true,
    },
  ],

  /** Ruta al .proto (solo se carga si algún feed llega en binario) */
  rutaProto: 'data/gtfs-realtime.proto',
  /** protobuf.js en versión ESM desde CDN, cargado bajo demanda */
  cdnProtobuf: 'https://cdn.jsdelivr.net/npm/protobufjs@7.4.0/+esm',
};
